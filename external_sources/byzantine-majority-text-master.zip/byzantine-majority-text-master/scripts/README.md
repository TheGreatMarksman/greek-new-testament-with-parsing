# Scripts to convert the files to Unicode

The scripts have dependencies, which are listed in the `requirements.txt` file. To install them, you can run `pip install -r requirements.txt`.

## Csv converter

You call it using `python3 csv_converter.py` (or `python csv_converter.py` depending on your particular settings.) It has been tested on Ubuntu 22.04 and Python 3.10.
