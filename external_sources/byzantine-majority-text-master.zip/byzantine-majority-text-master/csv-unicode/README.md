# Unicode versions of the Byzantine text in `.csv` format

This folder contains Unicode versions of the original `.CCAT` and `.BP5` files produced by Prof. Robinson. The `.csv` files in this folder are provided to you merely as a convenience. Professor Robinson's files remain the ultimate source of truth.

The scripts used to convert the files to the Unicode `.csv`s are in the `scripts` folder (see that folder's `README` for details).